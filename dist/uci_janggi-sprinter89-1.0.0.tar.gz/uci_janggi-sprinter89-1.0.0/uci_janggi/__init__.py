#this file does nothing except informing pypi that uci_janggi.py is a package
